// lib/db/index.ts
export { prisma } from './prisma';
export { default } from './prisma';
