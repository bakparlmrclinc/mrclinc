// Real verified statistics only - NO fake MrClinc-specific stats
export const REAL_STATS = {
  turkeyHealthTourism: "1.2M+ international patients annually",
  antalyaTourism: "World's 8th most visited city",
  jciHospitals: "50+ JCI-accredited hospitals in Turkey",
};
