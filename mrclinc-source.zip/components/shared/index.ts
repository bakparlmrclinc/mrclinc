// Shared components - extract common patterns here
// Examples: Section wrapper, PageHeader, StatusBadge, etc.
